import javax.swing.*;
import java.io.IOException;

public class Run{

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Game game = new Game();
        game.menu();

    }

}

